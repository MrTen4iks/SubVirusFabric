package com.subworld.subvirus.registry.materials;

import com.subworld.subvirus.registry.SubTags;
import net.minecraft.item.ToolMaterial;


public class SubItemMaterials {

    public static final ToolMaterial INFECTED_TOOL_MATERIAL = new ToolMaterial(
            SubTags.Blocks.INCORRECT_FOR_INFECTED_TOOL,
            6400,
            50.0F,
            5.0F,
            22,
            SubTags.Items.INFECTED_INGOT_REPAIR
    );


}

