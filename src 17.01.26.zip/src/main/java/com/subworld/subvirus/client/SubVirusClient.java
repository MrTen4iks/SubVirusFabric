package com.subworld.subvirus.client;


import com.subworld.subvirus.client.render.armor.HazmatArmorRenderer;
import net.fabricmc.api.ClientModInitializer;
import software.bernie.geckolib.renderer.GeoArmorRenderer;

public class SubVirusClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

    }
}
