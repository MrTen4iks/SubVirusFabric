package com.subworld.subvirus.world.items.armor;

/*
import net.minecraft.item.Item;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animatable.processing.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;
*/

import net.minecraft.item.Item;


public class HazmatArmorPackItem extends Item {
    public HazmatArmorPackItem(Item.Settings settings) {
        super(settings);
    }
}
